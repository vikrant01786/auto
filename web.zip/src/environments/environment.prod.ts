export const environment = {
  production: true,
  apiUrl: 'http://207.180.211.251:50009/',
  appUrl: 'http://207.180.211.251/Autosure/web/'
};
