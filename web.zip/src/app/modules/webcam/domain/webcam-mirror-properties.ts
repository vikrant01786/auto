export class WebcamMirrorProperties {
  public x: string;  // ["auto", "always", "never"]
}
