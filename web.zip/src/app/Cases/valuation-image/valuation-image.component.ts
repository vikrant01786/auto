import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-valuation-image',
  templateUrl: './valuation-image.component.html',
  styleUrls: ['./valuation-image.component.css']
})
export class ValuationImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
