export class Customer {
    GrievanceType: string;
    Subject: string;
    ContactPerson: string;
    MobileNumber: number;
    EmailId: string;
    Message: string;
}
