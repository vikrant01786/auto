export class User {
    UserId: number;
    Name: string;
    Address:string;
    MobileNo: string;
    AlternateNo: string;
    Email: string;
    Password: string;
    UserRole: number;
    ProfilePicture: string;
    InsurerName: number;
    Status:number;
}
