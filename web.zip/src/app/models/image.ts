export class Image {
    Id: number;
    IntimationID: number;
    ImageType: string;
    ImageURL: string;
    Location: string;
    Latitude: string;
    Longitude: string;
    Status: number;
    Time: string;
}
