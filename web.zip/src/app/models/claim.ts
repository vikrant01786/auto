export class Claim {
    RefNo: string;
    DateofRegistration:string;
    ClaimAmountEstimated:number;
    InsuranceCompanyClaimNo:string;
    PolicyCondition:string;
    ClaimRemarks:string;
    // status:number;


}
